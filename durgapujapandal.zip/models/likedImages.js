
// const mongoose = require("mongoose")

// const likedimagesShema = mongoose.Schema({
//     imageId: String,
//     usersId: Array,
//     year: String,
//     time:String,
// })


// const imageModel = mongoose.model("images", likedimagesShema)

// module.exports = {
//     imageModel
// }