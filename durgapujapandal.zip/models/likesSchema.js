// const mongoose = require("mongoose")

//  const likeSchema = mongoose.Schema({
//     userID: { type: String, required: true },
//     time: { type: Date, default: Date.now }
//   });

//   const liked = mongoose.model("likes", likeSchema)
//   module.export = {
//     liked
//   }